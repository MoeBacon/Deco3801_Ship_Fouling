import axios from 'axios'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import FootageDropZone, { FOOTAGE_MAX_BYTES } from '../components/FootageDropZone'
import ImportStatusCard from '../components/ImportStatusCard'
import PageHeader from '../components/PageHeader'
import VesselDetailsForm from '../components/VesselDetailsForm'
import { formatBytes } from '../lib/formatBytes'
import { importInspection, type ImportInspectionResponse, type VesselFormPayload } from '../lib/importInspection'

const emptyVessel: VesselFormPayload = {
  vessel_name: '',
  inspection_date: '',
  operator_name: '',
  location: '',
  notes: '',
}

function isAxiosDetail(d: unknown): d is { detail?: unknown } {
  return typeof d === 'object' && d !== null && 'detail' in d
}

function formatApiError(err: unknown): string {
  if (axios.isAxiosError(err) && !err.response) {
    return (
      'Could not reach the API (connection refused or no response). ' +
      'Start FastAPI in another terminal: cd backend → python -m uvicorn main:app --reload --host 127.0.0.1 --port 8000. ' +
      'Keep npm run dev running so /api is proxied to port 8000.'
    )
  }

  if (err && typeof err === 'object' && 'response' in err) {
    const r = err as { response?: { data?: unknown } }
    const data = r.response?.data
    if (typeof data === 'string') return data
    if (isAxiosDetail(data)) {
      const d = data.detail
      if (typeof d === 'string') return d
      if (Array.isArray(d)) return d.map((x) => (typeof x === 'object' && x && 'msg' in x ? String((x as { msg: string }).msg) : String(x))).join('; ')
    }
  }
  if (err instanceof Error) return err.message
  return 'Import failed. Is the Python API running on port 8000?'
}

export default function UploadPage() {
  const navigate = useNavigate()
  const [vessel, setVessel] = useState<VesselFormPayload>(emptyVessel)
  const [file, setFile] = useState<File | null>(null)
  const [footageError, setFootageError] = useState<string | null>(null)
  const [importError, setImportError] = useState<string | null>(null)
  const [uploading, setUploading] = useState(false)
  const [result, setResult] = useState<ImportInspectionResponse | null>(null)

  const onPickFile = (f: File | null) => {
    setImportError(null)
    setResult(null)
    setFootageError(null)
    if (f && f.size > FOOTAGE_MAX_BYTES) {
      setFootageError(`File exceeds maximum size of ${formatBytes(FOOTAGE_MAX_BYTES)}.`)
      setFile(null)
      return
    }
    setFile(f)
  }

  const runImport = async () => {
    if (!file) {
      setImportError('Select a video or image file first.')
      return
    }
    setImportError(null)
    setUploading(true)
    setResult(null)
    try {
      const data = await importInspection(file, vessel)
      setResult(data)
      if (!data.ok) {
        setImportError('Video processing failed on the backend. Check FastAPI logs for details.')
      }
    } catch (e) {
      setImportError(formatApiError(e))
    } finally {
      setUploading(false)
    }
  }

  const goAnalysis = () => {
    if (!result?.ok) return
    navigate('/analysis', { state: { import: result } })
  }

  const busy = uploading

  return (
    <div className="flex min-h-full min-w-0 flex-1 flex-col">
      <PageHeader breadcrumbs={['Inspections', 'New Import']} title="Upload & Import Inspection" />

      <div className="flex min-w-0 flex-1 flex-col gap-6">
        <VesselDetailsForm value={vessel} onChange={setVessel} disabled={busy} />

        <FootageDropZone file={file} onFile={onPickFile} disabled={busy} error={footageError} />

        {importError ? (
          <div className="rounded-lg border border-status-sev/40 bg-status-sev/10 px-4 py-3 text-sm text-red-100">
            {importError}
          </div>
        ) : null}

        <ImportStatusCard uploading={uploading} result={result} clientFile={file} />

        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <button
            type="button"
            disabled={busy || !file}
            onClick={runImport}
            className="inline-flex w-full items-center justify-center rounded-xl border border-border bg-surface-2 px-4 py-3 text-sm font-semibold text-white hover:bg-surface-1 disabled:opacity-50 sm:w-auto"
          >
            {uploading ? 'Uploading & processing…' : 'Upload video & queue job'}
          </button>

          <button
            type="button"
            disabled={!result?.ok || busy}
            onClick={goAnalysis}
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-accent px-4 py-3.5 text-sm font-semibold text-white shadow-sm hover:bg-accent-hover disabled:opacity-50 sm:ml-auto sm:w-auto sm:min-w-[200px]"
          >
            <span>Run analysis</span>
            <svg className="size-4" viewBox="0 0 24 24" fill="currentColor" aria-hidden>
              <path d="M8 5v14l11-7L8 5Z" />
            </svg>
          </button>
        </div>

        <p className="text-xs text-muted">
          Backend: <code className="rounded bg-surface-1 px-1 py-0.5 text-slate-300">uvicorn app.main:app --reload</code>.
          Vite proxies <code className="rounded bg-surface-1 px-1 py-0.5 text-slate-300">/api</code> and{' '}
          <code className="rounded bg-surface-1 px-1 py-0.5 text-slate-300">/static</code> to that server.
        </p>
      </div>
    </div>
  )
}
