import axios from 'axios'

/**
 * Axios instance for the K-ROV backend.
 * Dev: Vite proxies `/api` and `/static` to FastAPI (`uvicorn` on port 8000).
 * Prod: set `VITE_API_BASE_URL` to your API origin (include `/api/v1` if your routes are versioned).
 */
export const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL ?? '/api/v1',
})
