import { api } from './api'

export type VesselFormPayload = {
  vessel_name: string
  inspection_date: string
  operator_name: string
  location: string
  notes: string
}

export type ImportInspectionResponse = {
  ok: boolean
  vessel: VesselFormPayload
  file: {
    client_filename: string | null
    content_type: string | null
    size_bytes: number
  }
  video_id: string
  job: JobStatusResponse
  frames: FrameResponse[]
}

export type VideoUploadResponse = {
  video_id: string
  status: 'queued' | 'processing' | 'done' | 'error' | string
}

export type JobStatusResponse = {
  video_id: string
  status: 'queued' | 'processing' | 'done' | 'error' | string
  frame_count?: number | null
  duration?: number | null
}

export type FrameResponse = {
  frame_id: string
  video_id: string
  frame_number: number
  timestamp_in_video: number
  image_url: string
  enhancement_applied?: string | null
}

export type DetectionResponse = {
  detection_id: string
  frame_id: string
  class_label: string
  confidence: number
}

export async function uploadVideo(file: File): Promise<VideoUploadResponse> {
  const body = new FormData()
  body.append('file', file)

  const { data } = await api.post<VideoUploadResponse>('/videos', body)
  return data
}

export async function getJobStatus(videoId: string): Promise<JobStatusResponse> {
  const { data } = await api.get<JobStatusResponse>(`/jobs/${videoId}`)
  return data
}

export async function getVideoFrames(videoId: string): Promise<FrameResponse[]> {
  const { data } = await api.get<FrameResponse[]>(`/videos/${videoId}/frames`)
  return data
}

export async function getFrameDetections(frameId: string): Promise<DetectionResponse[]> {
  const { data } = await api.get<DetectionResponse[]>(`/frames/${frameId}/detections`)
  return data
}

async function pollJobUntilDone(
  videoId: string,
  onStatus: (status: JobStatusResponse) => void,
  intervalMs = 1500,
  timeoutMs = 5 * 60 * 1000,
): Promise<JobStatusResponse> {
  const start = Date.now()
  // First poll happens immediately so UI can show "queued/processing" quickly.
  for (;;) {
    const job = await getJobStatus(videoId)
    onStatus(job)

    if (job.status === 'done' || job.status === 'error') {
      return job
    }

    if (Date.now() - start > timeoutMs) {
      throw new Error('Timed out while waiting for video processing to finish.')
    }

    await new Promise((resolve) => setTimeout(resolve, intervalMs))
  }
}

export async function importInspection(file: File, vessel: VesselFormPayload): Promise<ImportInspectionResponse> {
  const upload = await uploadVideo(file)
  let latestStatus: JobStatusResponse = {
    video_id: upload.video_id,
    status: upload.status,
    frame_count: null,
    duration: null,
  }

  const job = await pollJobUntilDone(upload.video_id, (status) => {
    latestStatus = status
  })

  const frames = job.status === 'done' ? await getVideoFrames(upload.video_id) : []

  return {
    ok: job.status === 'done',
    vessel,
    file: {
      client_filename: file.name,
      content_type: file.type || null,
      size_bytes: file.size,
    },
    video_id: upload.video_id,
    job: latestStatus,
    frames,
  }
}
