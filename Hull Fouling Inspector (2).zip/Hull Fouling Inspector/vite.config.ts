import tailwindcss from '@tailwindcss/vite'
import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

// https://vite.dev/config/
const apiProxy = {
  '/api': {
    target: 'http://127.0.0.1:8000',
    changeOrigin: true,
  },
  '/static': {
    target: 'http://127.0.0.1:8000',
    changeOrigin: true,
  },
} as const

export default defineConfig({
  plugins: [react(), tailwindcss()],
  /** Dev server (`npm run dev`) — forwards /api to FastAPI. */
  server: { proxy: { ...apiProxy } },
  /** `npm run preview` — same proxy so imports work after build. */
  preview: { proxy: { ...apiProxy } },
})
