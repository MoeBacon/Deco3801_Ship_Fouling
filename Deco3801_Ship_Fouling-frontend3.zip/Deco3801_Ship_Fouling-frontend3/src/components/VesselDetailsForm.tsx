import type { VesselFormPayload } from '../features/import/types'

type VesselDetailsFormProps = {
  value: VesselFormPayload
  onChange: (next: VesselFormPayload) => void
  disabled?: boolean
}

const fields: { key: keyof VesselFormPayload; label: string; type: string; placeholder?: string }[] = [
  { key: 'vessel_name', label: 'Vessel name', type: 'text', placeholder: 'e.g. Oceanic Explorer' },
  { key: 'inspection_date', label: 'Inspection date', type: 'date', placeholder: '' },
  { key: 'operator_name', label: 'Operator name', type: 'text', placeholder: 'ROV pilot / inspector' },
  { key: 'location', label: 'Location / port', type: 'text', placeholder: 'Port of Brisbane' },
]

export default function VesselDetailsForm({ value, onChange, disabled }: VesselDetailsFormProps) {
  const set = (key: keyof VesselFormPayload, v: string) => onChange({ ...value, [key]: v })

  return (
    <section className="rounded-xl border border-border bg-surface-1 p-6">
      <h2 className="text-base font-semibold text-white">Vessel details</h2>
      <p className="mt-1 text-sm text-muted">Metadata is sent with your footage to the import API.</p>

      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        {fields.map(({ key, label, type, placeholder }) => (
          <div key={key} className="space-y-2">
            <label className="text-xs font-medium uppercase tracking-wide text-muted" htmlFor={key}>
              {label}
            </label>
            <input
              id={key}
              name={key}
              type={type}
              disabled={disabled}
              placeholder={placeholder}
              value={value[key]}
              onChange={(e) => set(key, e.target.value)}
              className="w-full rounded-lg border border-border bg-surface-0 px-3 py-2.5 text-sm text-white outline-none ring-accent/30 placeholder:text-slate-500 focus:border-accent focus:ring-2 disabled:opacity-60"
            />
          </div>
        ))}
      </div>

      <div className="mt-4 space-y-2">
        <label className="text-xs font-medium uppercase tracking-wide text-muted" htmlFor="notes">
          Optional notes
        </label>
        <textarea
          id="notes"
          name="notes"
          rows={4}
          disabled={disabled}
          placeholder="Dock number, cleaning scope, visibility, …"
          value={value.notes}
          onChange={(e) => set('notes', e.target.value)}
          className="w-full resize-y rounded-lg border border-border bg-surface-0 px-3 py-2.5 text-sm text-white outline-none ring-accent/30 placeholder:text-slate-500 focus:border-accent focus:ring-2 disabled:opacity-60"
        />
      </div>
    </section>
  )
}
